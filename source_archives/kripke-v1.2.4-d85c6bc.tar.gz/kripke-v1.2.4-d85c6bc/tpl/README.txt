Third Party Libraries

Subdirectories in ./tpl/ contain third party libraries that Kripke depends on.

tpl/raja   -   (REQUIRED)  RAJA programming model 
